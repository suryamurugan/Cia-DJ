/* let temp = document.body.getBoundingClientRect();
let x = (temp.y / temp.height) * -1;

onscroll = () => {
    temp = document.body.getBoundingClientRect();
    x = (temp.y / temp.height) * -1;
    console.log(x);
    
}
 */